ALTER TABLE character_inventory
   ADD UNIQUE KEY `idx_item` (`item`);
