ALTER TABLE `areatrigger_graveyard`
    RENAME TO `game_graveyard`;

ALTER TABLE `areatrigger_graveyard_zone`
    RENAME TO `game_graveyard_zone`;
