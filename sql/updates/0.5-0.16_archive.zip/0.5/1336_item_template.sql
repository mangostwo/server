ALTER TABLE `item_template` ADD `RangedModRange` float NOT NULL default '0' AFTER `ammo_type` ;
