ALTER TABLE `item_template` ADD `Unknown1` int(30) unsigned NOT NULL default '0' AFTER `area` ;
