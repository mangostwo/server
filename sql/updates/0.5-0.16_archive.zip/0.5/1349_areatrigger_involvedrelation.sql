ALTER TABLE `areatrigger_involvedrelation` DROP `creature` ;
