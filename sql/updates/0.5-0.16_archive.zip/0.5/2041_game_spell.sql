DROP TABLE IF EXISTS `game_spell`;
