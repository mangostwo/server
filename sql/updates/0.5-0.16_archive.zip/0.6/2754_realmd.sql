ALTER TABLE account CHANGE COLUMN `email` `email` varchar(255) NOT NULL default '';
