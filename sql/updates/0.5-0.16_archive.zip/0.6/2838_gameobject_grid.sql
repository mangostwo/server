ALTER TABLE `gameobject_grid` ENGINE = MEMORY;
