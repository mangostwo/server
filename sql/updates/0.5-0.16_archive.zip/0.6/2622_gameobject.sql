ALTER TABLE gameobject ADD COLUMN `animprogress` int(11) unsigned NOT NULL default '0';
