ALTER TABLE `character_pet`
  ADD `name` varchar(12) default 'Pet' AFTER `trainpoint`;
