ALTER TABLE `playercreateinfo`
  DROP `BaseStrength`,
  DROP `BaseAgility`,
  DROP `BaseStamina`,
  DROP `BaseIntellect`,
  DROP `BaseSpirit`,
  DROP `BaseArmor`,
  DROP `BaseHealth`,
  DROP `BaseMana`,
  DROP `BaseRage`,
  DROP `BaseFocus`,
  DROP `BaseEnergy`;

