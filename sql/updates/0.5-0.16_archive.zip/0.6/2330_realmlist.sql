ALTER TABLE `realmd`.`realmlist`
    ADD `port` int(11) NOT NULL default '8085' AFTER `address`;
