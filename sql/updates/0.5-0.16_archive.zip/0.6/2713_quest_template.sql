alter table quest_template
  drop column detailsemote;
alter table quest_template
  drop column completeemote;
alter table quest_template
  drop column incompleteemote;