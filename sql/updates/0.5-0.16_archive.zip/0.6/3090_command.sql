INSERT INTO `command` (`name`,`security`,`help`) VALUES ('respawn',3,'Syntax: .respawn\r\n\r\nRespawn all nearest creatures and GO without waiting respawn time expiration.');
