UPDATE `command` SET `help` = 'Syntax: .revive [$playername]\r\n\r\n  Revive specified or selected player. If no player is selected, it will revive you.' WHERE `name` = 'revive';
