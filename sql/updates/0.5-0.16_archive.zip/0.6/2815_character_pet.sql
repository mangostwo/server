ALTER TABLE `character_pet`
  CHANGE COLUMN `name` `name` varchar(100) NULL DEFAULT 'Pet';
