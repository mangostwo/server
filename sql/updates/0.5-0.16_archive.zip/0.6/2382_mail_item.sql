DROP TABLE IF EXISTS `mail_item`;
